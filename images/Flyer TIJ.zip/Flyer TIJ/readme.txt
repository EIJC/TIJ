Sehr geehrte Damen und Herren, 

vielen Dank, dass Sie die "Treffen Internationaler Journalisten" durch die Aush�nge der Plakate und Handzettel in Ihrer Beratungsstellung, Gemeinschaftsunterkunft, etc. unterst�tzen m�chten. 

In diesem Ordner finden Sie sowohl die Ank�ndigungsplakate als auch die Handzettel in den verschiedenen Sprachen Deutsch, Arabisch und Englisch. 

M�chten Sie die Handzettel selbst ausdrucken, w�hlen Sie in Ihrem Drucker einfach die Option "Papier beidseitig bedrucken" und "an langer Kante spiegeln".

An den Seitenr�ndern finden Sie Schnittmarken f�r den Zuschnitt der Handzettel. 

Vielen herzlichen Dank f�r Ihre Unterst�tzung!

Ihr Team der Internationalen Journalisten